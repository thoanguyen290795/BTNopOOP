import java.util.ArrayList;
import java.util.Scanner;

public class DanhSachGiaoDich {
	// 1. attributes
	ArrayList<GiaoDichDat> listGiaoDich;
	protected int tinhTongSL;
	protected int slA;
	protected int slB;
	protected int slC;
	// 2. get set

	public ArrayList<GiaoDichDat> getListGiaoDich() {
		return listGiaoDich;
	}

	public void setListGiaoDich(ArrayList<GiaoDichDat> listGiaoDich) {
		this.listGiaoDich = listGiaoDich;
	}

	public int getTinhTongSL() {
		return tinhTongSL;
	}

	public void setTinhTongSL(int tinhTongSL) {
		this.tinhTongSL = tinhTongSL;
	}

	public int getSlA() {
		return slA;
	}

	public void setSlA(int slA) {
		this.slA = slA;
	}

	public int getSlB() {
		return slB;
	}

	public void setSlB(int slB) {
		this.slB = slB;
	}

	public int getSlC() {
		return slC;
	}

	public void setSlC(int slC) {
		this.slC = slC;
	}

	// 3. constructor
	public DanhSachGiaoDich() {
		this.listGiaoDich = new ArrayList<GiaoDichDat>();

	}

//4. business method 
	public void dummyData() {
		GiaoDichDat gd;
		gd = new loaiA("1a", "29", "07", "1995", 2000, 50, 1);
		this.listGiaoDich.add(gd);

		gd = new loaiA("2a", "14", "03", "1997", 3000, 60, 2);
		this.listGiaoDich.add(gd);

		gd = new loaiB("3b", "22", "05", "2002", 4000, 70);
		this.listGiaoDich.add(gd);
		
		gd = new loaiB("4b", "27", "08", "2014", 5000, 100);
		this.listGiaoDich.add(gd); 
		
		gd = new loaiC("4c", "27", "05", "2008", 5000, 80);
		this.listGiaoDich.add(gd);
		
		gd = new loaiA("5a", "16", "9", "2013", 20000, 80, 1);
		this.listGiaoDich.add(gd);
		
		gd = new loaiB("7b", "03", "9", "2013", 30000, 100);
		this.listGiaoDich.add(gd);
		
		gd = new loaiC("6c", "27", "9", "2014", 3700, 80);
		this.listGiaoDich.add(gd);
	}

	public void nhap(Scanner scan) {
		boolean flag = true;
		GiaoDichDat gd;
		do {
			System.out.println("Nhập loại đất: ");
			System.out.println("1. Loại A: ");
			System.out.println("2. Loại B: ");
			System.out.println("3. Loại C: ");
			System.out.println("4. Thoát");
			int chon = Integer.parseInt(scan.nextLine());
			switch (chon) {
			case 1:
				gd = new loaiA();
				gd.nhap(scan);
				gd.tinhTien();
				this.listGiaoDich.add(gd);
				break;
			case 2:
				gd = new loaiB();
				gd.nhap(scan);
				gd.tinhTien();
				this.listGiaoDich.add(gd);
				break;
			case 3:
				gd = new loaiC();
				gd.nhap(scan);
				gd.tinhTien();
				this.listGiaoDich.add(gd);
				break;
			case 4:
				flag = false;
				break;
			}
		} while (flag);
	}

	public void xuat() {
		for (GiaoDichDat gd : this.listGiaoDich) {
			gd.xuat();
		}
	}

	public void tinhTien() {
		for (GiaoDichDat gd : this.listGiaoDich) {
			gd.tinhTien();
		}
	}

	public void tinhTongSL() {
		this.slA = 0;
		this.slB = 0;
		this.slC = 0;
		for (GiaoDichDat gd : this.listGiaoDich) {
			if (gd instanceof loaiA) {
				this.slA++;
			} else if (gd instanceof loaiB) {
				this.slB++;
			} else {
				this.slC++;
			}
		}
	}
public void xuatTongSL() {
	if (this.slA != 0  || this.slB !=  0 || this.slC != 0 ) {
		System.out.println("SL Loại A: " + this.slA);
		System.out.println("SL Loại B: " + this.slB);
		System.out.println("SL Loại C: " + this.slC);
}
}
public float tbGD2013() {
	float tbThanhTien = 0; 
	for (GiaoDichDat gd : this.listGiaoDich) {
		if (gd.getNamGD().equalsIgnoreCase("2013") && 
				gd.getThangGD().equalsIgnoreCase("9")) {
			tbThanhTien+= gd.getThanhTien();
		}
	} 
	return tbThanhTien; 
}
public void xuatGD2013() {
	for (GiaoDichDat gd : this.listGiaoDich) {
		if (gd.getNamGD().equalsIgnoreCase("2013") && 
				gd.getThangGD().equalsIgnoreCase("9")) {
			
			gd.xuat();
		}
	} 
}
}
