import java.util.Scanner;

/*
 * Mục đích: Quản Lý Giao Dịch đất loại B; 
 * */
public class loaiB extends GiaoDichDat {
//1. attributes 
	
//2. get set 
//3. constructor 
//4. input output 
//5. business method 
	public loaiB() {
		// TODO Auto-generated constructor stub
	}

	public loaiB(String maGiaoDich, String ngayGD, String thangGD, 
			String namGD, float donGia, float dienTich) {
			super(maGiaoDich, ngayGD, thangGD, namGD, donGia, dienTich);
			}
@Override
public void tinhTien() {
	this.thanhTien = this.dienTich * this.donGia; 
}
@Override 
public void xuat() {
	System.out.println("Mã giao dịch: " + this.maGiaoDich + 
			"\t Ngày GD: " + this.ngayGD + 
			"\t Tháng GD: " + this.thangGD + 
			"\t Năm GD: " + this.namGD + 
			"\t Đơn Giá: " + this.donGia + 
			"\t Diện tích: " + this.dienTich + 
			"\t Thành tiền: " + this.thanhTien);

}
} 
