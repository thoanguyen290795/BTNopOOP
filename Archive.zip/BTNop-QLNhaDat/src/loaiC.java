
public class loaiC extends GiaoDichDat {

	public loaiC() {
		// TODO Auto-generated constructor stub
	}

	public loaiC(String maGiaoDich, String ngayGD, String thangGD, String namGD, float donGia, float dienTich) {
			super(maGiaoDich, ngayGD, thangGD, namGD, donGia, dienTich);
			}
	@Override
	public void tinhTien() {
		this.thanhTien = this.dienTich * this.donGia; 
	}
	@Override 
	public void xuat() {
		System.out.println("Mã giao dịch: " + this.maGiaoDich + 
				"\t Ngày GD: " + this.ngayGD + 
				"\t Tháng GD: " + this.thangGD + 
				"\t Năm GD: " + this.namGD + 
				"\t Đơn Giá: " + this.donGia + 
				"\t Diện tích: " + this.dienTich + 
				"\t Thành tiền: " + this.thanhTien);
}
} 
