import java.util.Scanner;

public class xuLy {

	public xuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		GiaoDichDat gd = new GiaoDichDat(); 
		DanhSachGiaoDich listGD = new DanhSachGiaoDich(); 
		Scanner scan = new Scanner(System.in);
		listGD.dummyData();
		listGD.nhap(scan);
		listGD.tinhTien();
		listGD.tinhTongSL();
		listGD.xuat();
		System.out.println("Mã Giao Dịch của tháng 9 năm 2013: ");
		listGD.xuatGD2013(); 
		listGD.xuatTongSL();
	}

}
