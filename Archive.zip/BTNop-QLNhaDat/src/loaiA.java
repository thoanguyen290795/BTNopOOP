import java.util.Scanner;

/*
 * giao dich loai dat A ke thua tu GiaoDichDat 
 * */
public class loaiA extends GiaoDichDat {
//1. attributes 
	protected int loaiNha; 
//2. get set 
	public int getLoaiNha() {
		return loaiNha;
	}

	public void setLoaiNha(int loaiNha) {
		this.loaiNha = loaiNha;
	}
//3. constructor 
	public loaiA() {
		// TODO Auto-generated constructor stub
	}
	
public loaiA(String maGiaoDich, String ngayGD, String thangGD, String namGD,
		float donGia, float dienTich,
		 int loaiNha) {
		super(maGiaoDich, ngayGD, thangGD, namGD, donGia, dienTich);
		this.loaiNha = loaiNha; 
		
	}
	//4. input output
	@Override
	public void nhap(Scanner scan) {
		super.nhap(scan); 
		boolean flag = true; 
		do {
			System.out.println("Vui lòng nhập loại nhà: "); 
			System.out.println("1. Nhà cao cấp"); 
			System.out.println("2. Nhà thường"); 
			int chon = Integer.parseInt(scan.nextLine()); 
			switch(chon) {
			case 1: 
				this.loaiNha =  1; 
				flag = false; 
				break; 
			case 2: 
				this.loaiNha =  2;
				flag = false; 
				break; 
			default:
				System.out.println("Vui lòng nhập 1 hoặc 2");
			}
		}while(flag); 
	}
	@Override
	public void xuat() {
		super.xuat();
		System.out.println("\t Loại nhà: " + this.loaiNha);
	}
//5. business method 
	@Override 
	public void tinhTien() {
		if (this.loaiNha == 1) {
			this.thanhTien = this.dienTich * this.donGia; 
		} else {
			this.thanhTien = this.dienTich * this.donGia * 0.9f; 
		}
	}
}
