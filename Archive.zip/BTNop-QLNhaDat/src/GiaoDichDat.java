import java.util.Scanner;

/*
 * Quản lý giao dịch đất - parent 
 * */
public class GiaoDichDat {
//1. attributes 
	protected String maGiaoDich; 
	protected String ngayGD; 
	protected String thangGD; 
	protected String namGD; 
	protected float donGia; 
	protected float dienTich; 
	protected float thanhTien; 
	
//2. get set 
public String getMaGiaoDich() {
		return maGiaoDich;
	}

	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}

	public String getNgayGD() {
		return ngayGD;
	}

	public void setNgayGD(String ngayGD) {
		this.ngayGD = ngayGD;
	}

	public float getDonGia() {
		return donGia;
	}

	public void setDonGia(float donGia) {
		this.donGia = donGia;
	}

	public float getDienTich() {
		return dienTich;
	}

	public void setDienTich(float dienTich) {
		this.dienTich = dienTich;
	}

	public float getThanhTien() {
		return thanhTien;
	}
	public String getThangGD() {
		return thangGD;
	}

	public void setThangGD(String thangGD) {
		this.thangGD = thangGD;
	}

	public String getNamGD() {
		return namGD;
	}

	public void setNamGD(String namGD) {
		this.namGD = namGD;
	}

	public void setThanhTien(float thanhTien) {
		this.thanhTien = thanhTien;
	}
	//3. constructor 
	public GiaoDichDat() {
		// TODO Auto-generated constructor stub
	}
	public GiaoDichDat(String maGiaoDich, String ngayGD, 
			String thangGD, String namGD, 
			float donGia, float dienTich) {
		super();
		this.maGiaoDich = maGiaoDich;
		this.ngayGD = ngayGD;
		this.donGia = donGia;
		this.thangGD = thangGD; 
		this.namGD = namGD; 
		this.dienTich = dienTich;
	}
	
//4. input output 
	public void nhap(Scanner scan) {
		System.out.println("Nhập mã giao dịch: ");
		this.maGiaoDich = scan.nextLine();
		
		System.out.println("Nhập ngày giao dịch: ");
		this.ngayGD = scan.nextLine();
		System.out.println("Nhập tháng giao dịch: ");
		this.thangGD = scan.nextLine();
		
		System.out.println("Nhập năm giao dịch: ");
		this.namGD = scan.nextLine();
		
		System.out.println("Nhập đơn giá: "); 
		this.donGia = Float.parseFloat(scan.nextLine()); 
		
		System.out.println("Nhập diện tích: "); 
		this.dienTich = Float.parseFloat(scan.nextLine()); 
		
	}
	public void xuat() {
	System.out.print("Mã giao dịch: " + this.maGiaoDich + 
			"\t Ngày GD: " + this.ngayGD + 
			"\t Tháng GD: " + this.thangGD + 
			"\t Năm GD: " + this.namGD + 
			"\t Đơn Giá: " + this.donGia + 
			"\t Diện tích: " + this.dienTich + 
			"\t Thành tiền: " + this.thanhTien);
}
	public void tinhTien() {
		this.thanhTien = 0; 
	}

}
