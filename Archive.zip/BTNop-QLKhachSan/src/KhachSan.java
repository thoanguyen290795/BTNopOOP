import java.util.Scanner;

public class KhachSan {
//1. attributes 
	protected String maHoaDon; 
	protected String ngayHoaDon; 
	protected String thangHoaDon; 
	protected String namHoaDon; 
	protected String tenKH; 
	protected String maPhong; 
	protected float donGia; 
	protected float thanhTien; 
//2. get set 
	
	public String getMaHoaDon() {
		return maHoaDon;
	}

	public void setMaHoaDon(String maHoaDon) {
		this.maHoaDon = maHoaDon;
	}

	public String getNgayHoaDon() {
		return ngayHoaDon;
	}

	public void setNgayHoaDon(String ngayHoaDon) {
		this.ngayHoaDon = ngayHoaDon;
	}

	public String getThangHoaDon() {
		return thangHoaDon;
	}

	public void setThangHoaDon(String thangHoaDon) {
		this.thangHoaDon = thangHoaDon;
	}

	public String getNamHoaDon() {
		return namHoaDon;
	}

	public void setNamHoaDon(String namHoaDon) {
		this.namHoaDon = namHoaDon;
	}

	public String getTenKH() {
		return tenKH;
	}

	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}

	public String getMaPhong() {
		return maPhong;
	}

	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}

	public float getDonGia() {
		return donGia;
	}

	public void setDonGia(float donGia) {
		this.donGia = donGia;
	}
	public float getThanhTien() {
		return thanhTien;
	}

	//3. constructor 
	public KhachSan() {
		// TODO Auto-generated constructor stub
	}

	public KhachSan(String maHoaDon, String ngayHoaDon, String thangHoaDon, String namHoaDon, String tenKH,
			String maPhong, float donGia) {
		super();
		this.maHoaDon = maHoaDon;
		this.ngayHoaDon = ngayHoaDon;
		this.thangHoaDon = thangHoaDon;
		this.namHoaDon = namHoaDon;
		this.tenKH = tenKH;
		this.maPhong = maPhong;
		this.donGia = donGia;
	}
	
	//4. input output 
	public void nhap(Scanner scan) {
		System.out.println("Nhập mã Hoá Đơn: ");
		this.maHoaDon = scan.nextLine(); 
		
		System.out.println("Nhập ngày xuất Hoá Đơn: ");
		this.ngayHoaDon = scan.nextLine(); 
		
		System.out.println("Nhập tháng xuất Hoá Đơn: ");
		this.thangHoaDon = scan.nextLine(); 
		
		System.out.println("Nhập năm xuất Hoá Đơn: ");
		this.namHoaDon = scan.nextLine(); 
		
		System.out.println("Nhập tên Khách Hàng : ");
		this.tenKH = scan.nextLine(); 
		
		System.out.println("Nhập mã phòng: ");
		this.maPhong = scan.nextLine(); 
		
		System.out.println("Nhập đơn giá: ");
		this.donGia = Float.parseFloat(scan.nextLine()); 
	}
	public void xuat() {
		System.out.print("Mã HĐ: " + this.maHoaDon + 
				"\t Ngày HĐ: " + this.ngayHoaDon + 
				"\t Tháng HĐ: " + this.thangHoaDon + 
				"\t Năm HĐ: " + this.namHoaDon + 
				"\t Tên KH: " + this.tenKH + 
				"\t Mã phòng: " + this.maPhong + 
				"\t Đơn giá: " + this.donGia +
				"\t Thành Tiền: " + this.thanhTien);
	}
	//5. business method 
	public void tinhTien() {
		this.thanhTien = 0; 
	}

}
