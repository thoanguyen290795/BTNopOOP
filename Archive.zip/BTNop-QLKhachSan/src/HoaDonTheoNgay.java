import java.util.Scanner;

public class HoaDonTheoNgay extends KhachSan {
//1. attributes 
	protected float soNgay; 
//2. get set 
	
	public float getSoNgay() {
		return soNgay;
	}

	public void setSoNgay(float soNgay) {
		this.soNgay = soNgay;
	}
//3. constructor 
	
	public HoaDonTheoNgay() {
		// TODO Auto-generated constructor stub
	}

	public HoaDonTheoNgay(String maHoaDon, String ngayHoaDon, String thangHoaDon, String namHoaDon, 
			String tenKH,
			String maPhong, float donGia, float soNgay) {
		super(maHoaDon, ngayHoaDon, thangHoaDon, namHoaDon, tenKH, maPhong, donGia);
		this.soNgay = soNgay; 
	
	}
//4. input output 
@Override 
public void nhap(Scanner scan) {
	super.nhap(scan); 
	System.out.println("Số Ngày ở Khách Sạn: ");
	this.soNgay = Float.parseFloat(scan.nextLine()); 
}
@Override 
public void xuat() {
	super.xuat();
	System.out.println("\t Số ngày: " + this.soNgay);
}
@Override 
public void tinhTien() {
	this.thanhTien = this.soNgay * 24 * this.donGia; 
}

}
