import java.util.Scanner;

public class xuLy {

	public xuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		DanhSachHoaDon hd = new DanhSachHoaDon();
		hd.dummyData();
		hd.nhap(scan);
		hd.tinhTien();
		hd.xuat();
	}

}
