import java.util.ArrayList;
import java.util.Scanner;

public class DanhSachHoaDon {
//1. Attributes 
	ArrayList<KhachSan> listKH;
//2. get & set 

	public ArrayList<KhachSan> getListKH() {
		return listKH;
	}

	public void setListKH(ArrayList<KhachSan> listKH) {
		this.listKH = listKH;
	}

//3. constructor 
	public DanhSachHoaDon() {
		this.listKH = new ArrayList<KhachSan>();

	}

//4. input output 
	public void dummyData() {
		KhachSan ks;
		ks = new HoaDonTheoNgay("1", "29", "07", "2010", "Thoa", "21", 200, 2); 
		this.listKH.add(ks); 
		
		ks = new HoaDonTheoNgay("2", "22", "05", "2015", "Tâm", "30", 400, 3); 
		this.listKH.add(ks); 
		
		ks = new HoaDonTheoNgay("3", "27", "05", "2011", "Phúc", "20", 1200, 3); 
		this.listKH.add(ks); 
		
		ks = new HoaDonTheoGio("4", "22", "06", "2012", "Alice", "10", 1000, 13); 
		this.listKH.add(ks); 
		
		ks = new HoaDonTheoGio("5", "12", "09", "2015", "Paulina", "11", 1500, 36); 
		this.listKH.add(ks); 
	}
	public void nhap(Scanner scan) {
		boolean flag = true;
		KhachSan ks;
		do {
			System.out.println("Vui lòng nhập: ");
			System.out.println("1. Hoá đơn theo ngày");
			System.out.println("2. Hoá đơn theo giờ");
			System.out.println("3. Thoát");
			int chon = Integer.parseInt(scan.nextLine());
			switch (chon) {
			case 1:
				 ks  = new HoaDonTheoNgay(); 
				 ks.nhap(scan);
				 ks.tinhTien();
				 this.listKH.add(ks); 		 
				break;
			case 2:
				 ks  = new HoaDonTheoGio(); 
				 ks.nhap(scan);
				 ks.tinhTien();
				 this.listKH.add(ks); 
				break;
			case 3:
				flag = false; 
				break;
			}
		} while (flag);

	}
	public void xuat() {
		for (KhachSan ks: this.listKH) {
			ks.xuat();
		}
	}
	public void tinhTien() {
		for (KhachSan ks: this.listKH) {
			ks.tinhTien();
		}
	}

}
