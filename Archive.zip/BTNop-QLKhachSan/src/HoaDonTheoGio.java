import java.util.Scanner;

public class HoaDonTheoGio extends KhachSan {
//1. attributes
	protected float soGio; 
//2. get set 
	
	public float getSoGio() {
		return soGio;
	}

	public void setSoGio(float soGio) {
		this.soGio = soGio;
	}
//3. constructor
	public HoaDonTheoGio() {
		// TODO Auto-generated constructor stub
	}

	public HoaDonTheoGio(String maHoaDon, String ngayHoaDon, String thangHoaDon, String namHoaDon, String tenKH,
			String maPhong, float donGia, float soGio) {
		super(maHoaDon, ngayHoaDon, thangHoaDon, namHoaDon, tenKH, maPhong, donGia);
		this.soGio = soGio;
	}
//4. input output 
	@Override 
	public void nhap(Scanner scan) {
		super.nhap(scan); 
		System.out.println("Vui lòng nhập số giờ < 30 tiếng : ");
	}
	@Override 
	public void xuat() {
		super.xuat(); 
		System.out.println("\t Số Giờ : " + this.soGio);
	}
	//5. business method 
	@Override 
	public void tinhTien() {
		if(this.soGio < 30) {
			this.thanhTien = this.soGio * this.donGia; 
		} else if (this.soGio > 30) {
			System.out.println("Số giờ lớn hơn 30. Vui lòng sử dụng hoá đơn theo ngày");
			
		}
	}
}
