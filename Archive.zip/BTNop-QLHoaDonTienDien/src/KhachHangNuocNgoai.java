import java.util.Scanner;

public class KhachHangNuocNgoai extends KhachHang {
//1. attributes 
	protected String quocTich; 

	public KhachHangNuocNgoai() {
		// TODO Auto-generated constructor stub
	}

	public KhachHangNuocNgoai(String maKH, String hoTen, String ngayXuat, String thangXuat, String namXuat,
			float soLuong, float donGia, String quocTich) {
		super(maKH, hoTen, ngayXuat, thangXuat, namXuat, soLuong, donGia);
		this.quocTich = quocTich;
	}
	
	@Override 
	public void nhap(Scanner scan) {
		super.nhap(scan);
		System.out.println("Nhập quốc tịch: ");
		this.quocTich = scan.nextLine(); 
	}
	@Override 
	public void xuat() {
		super.xuat();
		System.out.println("\t Quốc tịch: " + this.quocTich);
	}
	@Override
	public void tinhTien() {
		this.thanhTien = this.soLuong * this.donGia; 
	}
}
