import java.util.Scanner;

public class KhachHang {
//1. attributes 
	protected String maKH; 
	protected String hoTen; 
	protected String ngayXuat; 
	protected String thangXuat; 
	protected String namXuat; 
	protected float soLuong; 
	protected float donGia; 
	protected float thanhTien; 
//2. get set 
	public String getMaKH() {
		return maKH;
	}

	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getNgayXuat() {
		return ngayXuat;
	}

	public void setNgayXuat(String ngayXuat) {
		this.ngayXuat = ngayXuat;
	}

	public String getThangXuat() {
		return thangXuat;
	}

	public void setThangXuat(String thangXuat) {
		this.thangXuat = thangXuat;
	}

	public String getNamXuat() {
		return namXuat;
	}

	public void setNamXuat(String namXuat) {
		this.namXuat = namXuat;
	}

	public float getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(float soLuong) {
		this.soLuong = soLuong;
	}

	public float getDonGia() {
		return donGia;
	}

	public void setDonGia(float donGia) {
		this.donGia = donGia;
	}

	public float getThanhTien() {
		return thanhTien;
	}
//3. constructor 
	public KhachHang() {
		// TODO Auto-generated constructor stub
	}

	public KhachHang(String maKH, String hoTen, String ngayXuat, String thangXuat, String namXuat, float soLuong,
			float donGia) {
		this.maKH = maKH;
		this.hoTen = hoTen;
		this.ngayXuat = ngayXuat;
		this.thangXuat = thangXuat;
		this.namXuat = namXuat;
		this.soLuong = soLuong;
		this.donGia = donGia;
		
	}
	
//4. input output 
	public void nhap(Scanner scan) {
		System.out.println("Nhập mã KH: ");
		this.maKH = scan.nextLine(); 
		
		System.out.println("Nhập họ tên KH: ");
		this.hoTen = scan.nextLine(); 
		
		System.out.println("Nhập ngày xuất Hoá Đơn: ");
		this.ngayXuat = scan.nextLine(); 
		
		System.out.println("Nhập tháng xuất Hoá Đơn: ");
		this.thangXuat = scan.nextLine(); 
		
		System.out.println("Nhập năm xuất Hoá Đơn: ");
		this.namXuat = scan.nextLine(); 
		
		System.out.println("Nhập Số Lượng : ");
		this.soLuong = Float.parseFloat(scan.nextLine()) ; 
		
		System.out.println("Nhập Đơn Giá: ");
		this.donGia = Float.parseFloat(scan.nextLine()) ; 
		
	}
	public void xuat() {
		System.out.print("Mã KH" + this.maKH + 
				"\t Họ Tên: " + this.hoTen + 
				"\t Ngày xuất HĐ: " + this.ngayXuat + 
				"\t Tháng xuất HĐ: " + this.thangXuat + 
				"\t Năm xuất HĐ: " + this.namXuat +
				"\t Số Lượng: " + this.soLuong + 
				"\t Đơn Giá: " + this.donGia + 
				"\t Thành Tiền: " + this.thanhTien);
	}
//5. business method 
	public void tinhTien() {
		this.thanhTien = 0; 
	}
}
