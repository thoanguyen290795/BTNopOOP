import java.util.Scanner;

public class xuLy {

	public xuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		DanhSachKhachHang ds = new DanhSachKhachHang(); 
		ds.dummyData();
		ds.tinhTien();
		ds.nhap(scan);
		ds.demSlKhachHang();
		ds.xuatSLKhachHang();
		float tbThanhTienKHNN = ds.tbThanhTienKHNN(); 
		ds.xuat();
		System.out.println("Trung Bình Thành Tiền của Khách Nước Ngoài: " + tbThanhTienKHNN);
		System.out.println("Khách Hàng mua vào tháng 9 năm 2013: ");
		ds.xuatHoaDonThang9Nam2013();
		
	}

}
