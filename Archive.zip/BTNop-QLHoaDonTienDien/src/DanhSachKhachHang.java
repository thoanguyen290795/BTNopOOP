import java.util.ArrayList;
import java.util.Scanner;

public class DanhSachKhachHang {
	protected ArrayList<KhachHang> listKH;
	protected int slKhachNuocNgoai; 
	protected int slKhachVN; 

	public ArrayList<KhachHang> getListKH() {
		return listKH;
	}

	public void setListKH(ArrayList<KhachHang> listKH) {
		this.listKH = listKH;
	}

	public DanhSachKhachHang() {
		// TODO Auto-generated constructor stub
		this.listKH = new ArrayList<KhachHang>();
	}
	public void dummyData() {
		KhachHang kh; 
		kh = new KhachHangVN("1", "Thoa", "29", "7", "1995", 20, 200, "thương mại", 
				"xe hơi", "hợp pháp", 50 );
		this.listKH.add(kh);
		kh = new KhachHangVN("2", "Trúc", "14", "7", "1997", 50, 300, "thương mại", 
				"flight ticket", "hợp pháp", 40 );
		this.listKH.add(kh);
		kh = new KhachHangNuocNgoai("3", "Tâm", "22", "5", "2002", 30, 200, "Thai Lan" );
		this.listKH.add(kh);
		
		kh = new KhachHangNuocNgoai("4", "Phát", "16", "9", "2013", 40, 300, "American" );
		this.listKH.add(kh);
		
		kh = new KhachHangNuocNgoai("5", "Lộc", "19", "9", "2013", 50, 250, "American" );
		this.listKH.add(kh);
	}
	public void nhap(Scanner scan) {
		boolean flag = true;
		KhachHang kh; 
		do {
			System.out.println("Vui Lòng Nhập: ");
			System.out.println("1. Khách Hàng Việt Nam");
			System.out.println("2. Khách Hàng Nước Ngoài");
			System.out.println("3. Thoát");
			int chon = Integer.parseInt(scan.nextLine());
			switch (chon) {
			case 1:
				kh = new KhachHangVN(); 
				kh.nhap(scan);
				kh.tinhTien();
				this.listKH.add(kh); 
				break;
			case 2:
				kh = new KhachHangNuocNgoai(); 
				kh.nhap(scan);
				kh.tinhTien();
				this.listKH.add(kh);
				break;
			case 3:
				flag = false; 
				break;
			}
		} while (flag);
	}
	public void xuat() {
		for (KhachHang kh: this.listKH) {
			kh.xuat(); 
		}
	}
	public void tinhTien() {
		for (KhachHang kh: this.listKH) {
			kh.tinhTien();
		}
	}
	public void demSlKhachHang() {
		this.slKhachNuocNgoai = 0; 
		this.slKhachVN = 0; 
		for (KhachHang kh: this.listKH) {
			if (kh instanceof KhachHangVN) {
				this.slKhachVN++; 
			} else {
				this.slKhachNuocNgoai++; 
			}
		}
	}
	public void xuatSLKhachHang() {
		System.out.println("Số Lượng Khách VN: " + this.slKhachVN);
		System.out.println("Số Lượng Khách Nước Ngoài: " + this.slKhachNuocNgoai);	
	}
	public float tbThanhTienKHNN() {
		float thanhTien = 0; 
		for(KhachHang kh: this.listKH) {
			if (kh instanceof KhachHangNuocNgoai) {
				thanhTien += kh.getThanhTien(); 
			}
		}
		return thanhTien; 
	}
	public void xuatHoaDonThang9Nam2013() {
		for (KhachHang kh: this.listKH) {
			if (kh.getNamXuat().equalsIgnoreCase("2013") && kh.getThangXuat().equalsIgnoreCase("9")) {
				kh.xuat();
			}
		}
	}
}
