import java.util.Scanner;

public class KhachHangVN extends KhachHang {
//1. attributes 
	protected String sinhHoat; 
	protected String kinhDoanh; 
	protected String sanXuat; 
	protected float dinhMuc; 
	
	public KhachHangVN() {
		// TODO Auto-generated constructor stub
	}

	public KhachHangVN(String maKH, String hoTen, String ngayXuat, String thangXuat, String namXuat, float soLuong,
			float donGia, String sinhHoat, String kinhDoanh, String sanXuat, float dinhMuc) {
		super(maKH, hoTen, ngayXuat, thangXuat, namXuat, soLuong, donGia);
		this.sinhHoat = sinhHoat; 
		this.kinhDoanh = kinhDoanh; 
		this.sanXuat = sanXuat; 
		this.dinhMuc = dinhMuc; 
				
	}
	@Override 
	public void nhap(Scanner scan) {
		super.nhap(scan);
		System.out.println("Nhập sinh hoạt: ");
		this.sinhHoat = scan.nextLine();
		
		System.out.println("Nhập kinh doanh: ");
		this.kinhDoanh = scan.nextLine(); 
		
		System.out.println("Nhập sản xuất: ");
		this.sanXuat = scan.nextLine(); 
		
		System.out.println("Nhập định mức:  ");
		this.dinhMuc = Float.parseFloat(scan.nextLine()); 
	}
	@Override 
	public void xuat() {
		super.xuat();
		System.out.println("\t Sinh Hoạt: " + this.sinhHoat + 
				"\t Kinh Doanh: " + this.kinhDoanh + 
				"\t Sản Xuất: " + this.sanXuat + 
				"\t Định Mức: " + this.dinhMuc);
	}
	@Override 
	public void tinhTien() {
		if (this.soLuong <= this.dinhMuc) {
			this.thanhTien = this.soLuong * this.donGia; 
		} else {
			this.thanhTien = this.soLuong * this.donGia * this.dinhMuc + 
					(this.soLuong - this.dinhMuc) * this.donGia * 2.5f; 
		}
	} 
}
